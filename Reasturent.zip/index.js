 dishes=document.querySelector("#dish");
// if(console.log(window.screen.width)){
//     dishes.classList.add("dishess")

// }

